CREATE USER szallasado1 WITHOUT login;
Grant SELECT ON FOGLALAS_MASKED to szallasado1