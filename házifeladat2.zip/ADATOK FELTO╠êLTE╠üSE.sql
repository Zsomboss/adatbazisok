INSERT INTO FOGLALAS_MASKED
(szallas_id,szallas_nev,szallas_email,cim,csillagok)
VALUES
('1001','Arany Nap Apartman','aranynap@example.com','1023 Arany utca 5.','4'),
('1002','Zöld Liget Panzió','info@zoldliget.hu','1055 Zöldliget tér 12.','3'),
('1003','Ezüst Horgony Kemping','ezusthorgony@example.com','2000 Tengerparti sétány 8.','2'),
('1004','Vörös Mennyország Hotel','reservation@vorosmennyorszag.com','1092 Vöröskereszt utca 21.','5'),
('1005','Kék Hegy Panzió','reception@kekhegypanzio.hu','1031 Kékhegy út 15.','3')